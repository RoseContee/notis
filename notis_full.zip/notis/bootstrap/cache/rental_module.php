<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Rental\\Providers\\RentalServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Rental\\Providers\\RentalServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);