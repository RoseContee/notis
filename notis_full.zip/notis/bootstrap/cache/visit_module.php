<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Visit\\Providers\\VisitServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Visit\\Providers\\VisitServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);