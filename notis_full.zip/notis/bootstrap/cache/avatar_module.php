<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Avatar\\Providers\\AvatarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Avatar\\Providers\\AvatarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);