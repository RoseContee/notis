<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\View\\Providers\\ViewServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\View\\Providers\\ViewServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);