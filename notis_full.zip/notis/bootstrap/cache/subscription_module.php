<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Subscription\\Providers\\SubscriptionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Subscription\\Providers\\SubscriptionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);