<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Show\\Providers\\ShowServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Show\\Providers\\ShowServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);